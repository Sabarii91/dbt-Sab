-- Compare counts using the SAME filter as stg_customers (CUST_NBR between 700099 and 800000)
select *
from (
    select
        abs(
            (select count(*) from {{ source('raw', 'CUST_SALES') }} where "CUST_NBR" between 700099 and 800000) -
            (select count(*) from {{ ref('stg_customers') }})
        ) as diff
)
where diff > 10