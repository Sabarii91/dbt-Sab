{% test compare_with_query(model, test_query, key_column, compare_columns) %}

with model_data as (
    select * from {{ model }}
),

expected_data as (
    {{ test_query }}
),

joined as (
    select
        coalesce(m.{{ key_column }}, e.{{ key_column }}) as record_id,
        m.{{ key_column }} as model_key,
        e.{{ key_column }} as expected_key,

        {% for col in compare_columns %}
        m.{{ col }} as model_{{ col }},
        e.{{ col }} as expected_{{ col }}
        {% if not loop.last %},{% endif %}
        {% endfor %}

    from model_data m
    full outer join expected_data e
        on m.{{ key_column }} = e.{{ key_column }}
),

-- Missing in model
missing_in_model as (
    select
        record_id as {{ key_column }},
        null as column_name,
        null as model_value,
        null as expected_value,
        'MISSING_IN_MODEL' as issue_type
    from joined
    where model_key is null
),

-- Extra in model
extra_in_model as (
    select
        record_id as {{ key_column }},
        null as column_name,
        null as model_value,
        null as expected_value,
        'EXTRA_IN_MODEL' as issue_type
    from joined
    where expected_key is null
),

-- Column mismatches
column_differences as (

    {% for col in compare_columns %}

    select
        record_id as {{ key_column }},
        '{{ col }}' as column_name,
        model_{{ col }} as model_value,
        expected_{{ col }} as expected_value,
        'MISMATCH' as issue_type
    from joined
    where
        model_{{ col }} != expected_{{ col }}
        or (model_{{ col }} is null and expected_{{ col }} is not null)
        or (model_{{ col }} is not null and expected_{{ col }} is null)

    {% if not loop.last %} union all {% endif %}

    {% endfor %}
)

select * from missing_in_model
union all
select * from extra_in_model
union all
select * from column_differences

{% endtest %}