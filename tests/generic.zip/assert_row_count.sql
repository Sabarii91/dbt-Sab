-- tests/assert_row_count_match.sql

with raw_count as (
    select count(*) as cnt
    from {{ source('raw', 'CUST_SALES') }}
),
silver_count as (
    select count(*) as cnt
    from {{ ref('stg_customers') }}
),
test_silver_count as (
    select count(*) as cnt
    from {{ ref('test_stg_customers') }}
)

select *
from raw_count r
join silver_count s
  on r.cnt != s.cnt
join test_silver_count ts
  on s.cnt != ts.cnt  